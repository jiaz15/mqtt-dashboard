require('dotenv').config();
const { InfluxDB } = require('@influxdata/influxdb-client');

// 从 .env 中读取配置
const token = process.env.INFLUX_TOKEN;
const org = process.env.INFLUX_ORG;
const bucket = process.env.INFLUX_BUCKET;
const url = process.env.INFLUX_URL;

const client = new InfluxDB({ url, token });
const queryApi = client.getQueryApi(org);

// 示例查询：获取 deviceId 为 sensor-001 的数据
const deviceId = 'sensor-001';
const fluxQuery = `
  from(bucket: "${bucket}")
    |> range(start: -1h)
    |> filter(fn: (r) => r.deviceId == "${deviceId}")
`;

let results = [];

queryApi.queryRows(fluxQuery, {
  next(row, tableMeta) {
    const o = tableMeta.toObject(row);
    console.log(`[${o._time}] ${o._field}: ${o._value}`);
    results.push(o);
  },
  error(error) {
    console.error('❌ 查询失败:', error);
  },
  complete() {
    console.log('✅ 查询完成, 共获取记录：', results.length);
  }
});